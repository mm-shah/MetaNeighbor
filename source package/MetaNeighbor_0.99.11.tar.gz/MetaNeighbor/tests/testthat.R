library(testthat)
library(MetaNeighbor)

test_check("MetaNeighbor")
